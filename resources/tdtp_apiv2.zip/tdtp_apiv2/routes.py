from flask import jsonify, abort, request, make_response, url_for, g
from tdtp_web import app 
from json import loads
from flask import request, session, flash
from flask import render_template, abort, redirect, url_for
import requests
import json
@app.route("/")
@app.route("/index")
def index():
    return render_template("index.html") 

@app.route("/login", methods=['GET', 'POST'])
def login():
    #vérifier si les champs ne sont pas vides et récupérer les valeurs dans un dictionnaire 
    # dialoguer le site web avec l'API en utilisant requests.get et vérifier si l'utilisateur existe ou non!!
    # si le .status_code==404 alors redirection vers error_404.html sinon créer la session et effectuer la redirection en fonction des roles
    if request.method == 'POST' and request.form['login'] and request.form['mdp'] and request.form['role']:
    
        pass

    elif request.method == 'POST':
        flash("Des champs ne sont pas saisis !", 'error')
    return render_template("login.html")

@app.route("/modules",methods=['GET'])
def getmodule():
    #listmodules reçoit le résultat de requests.get.Penser à enlever les commentaires des deux dernières lignes de la méthode 
    pass 
    #aList = json.loads(listmodules.text)
    #return render_template("modules.html",modules=aList) 

@app.route("/logout")
def logout():
    session.clear()
    return render_template("index.html")


@app.route("/user")
def user():
    return render_template("user.html")

@app.route("/updateuser")
def updateuser():
    return render_template("updateprofile.html")  

#méthode à compléter
@app.route("/updateProfileuser",methods=['POST','GET'])
def updateProfile():
    #récupérer les champs remplis par l'utilisateur et interoger l'api pour mettre à jour le profil de l'utilisateur
    pass
    return render_template("profile.html")
