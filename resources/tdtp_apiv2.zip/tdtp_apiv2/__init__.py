from flask import Flask
from flask_cors import CORS




app = Flask(__name__)
#session: initialiser la clé de signature
pass

from tdtp_web import routes
